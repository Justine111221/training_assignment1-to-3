---- INSERT INTO ADMIN 


insert into admins(email, password)  values('MayurDikShit@example.com', '3453678');
insert into admins(email, password)  values('ironman@timgarage.com', '2345078');
insert into admins(email, password)  values('jamesbond@xyzdetectiveagency.com', '1234567');
insert into admins(email, password)  values('raizenjir0@gmail.com', '21432543');
insert into admins(email, password)  values('eduardo.nicodemus18@gmail.com', '97684563');
insert into admins(email, password)  values('johnespiritu26@gmail.com', '6456356');


----- INSERT INTO Category
select * from categories;

INSERT INTO categories (category_name) VALUES ('Computer');
INSERT INTO categories (category_name) VALUES ('Laptop');
INSERT INTO categories (category_name) VALUES ('Cellphone');
INSERT INTO categories (category_name) VALUES ('Tablet');
INSERT INTO categories (category_name) VALUES ('PhoneTab');

---- INSERT INTO PRODUCTS
SELECT * FROM PRODUCTS

INSERT INTO products (
    product_name,
    category_id,
    product_price,
    product_image,
    product_available_qty)
    VALUES (
    'Keyboard',
    'CAT 0000001',
    1000.00,
    'keyboard.jpg',
    20
);

INSERT INTO products (
    product_name,
    category_id,
    product_price,
    product_image,
    product_available_qty)
    VALUES (
    'Mouse',
    'CAT 0000002',
    550.00,
    'mouse.jpg',
    20
);


INSERT INTO products (
    product_name,
    category_id,
    product_price,
    product_image,
    product_available_qty)
    
    VALUES (
    'Memory 8GB',
    'CAT 0000003',
    4500.00,
    'Memory.jpg',
    50
);

INSERT INTO products (
    product_name,
    category_id,
    product_price,
    product_image,
    product_available_qty)
    
    VALUES (
    'Monitor',
    'CAT 0000004',
    5500.00,
    'Monitor.jpg',
    20
);

INSERT INTO products (
    product_name,
    category_id,
    product_price,
    product_image,
    product_available_qty)
    
    VALUES (
    'Laptop Charger',
    'CAT 0000005',
    2500.00,
    'Charger.jpg',
    50
);




